<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
     <script type="text/javascript" src="ckplayer/ckplayer.js" charset="utf-8" data-name="ckplayer"></script>
<div class="video" style="width: 600px;height: 400px;">播放器容器</div>
<script type="text/javascript">
    //定义一个变量：videoObject，用来做为视频初始化配置
    var videoObject = {
        container: '.video', //“#”代表容器的ID，“.”或“”代表容器的class
        variable: 'player', //播放函数名称，该属性必需设置，值等于下面的new ckplayer()的对象
        video: 'https://cn-zjwz-cmcc-live-02.bilivideo.com/live-bvc/772545/live_11153765_9369560.m3u8?cdn=cn-gotcha01&expires=1604147788&len=0&oi=1972125021&pt=h5&qn=10000&trid=08a2e3875a0345b9883a5523fa0f9f03&sigparams=cdn,expires,len,oi,pt,qn,trid&sign=67bb28958aae1dbad9276de2cc674ca5&ptype=0&src=9&sl=1&order=1'//视频地址
    };
    var player = new ckplayer(videoObject);//初始化播放器
</script>
<meta charset="utf-8">
</head>


<title>哔哩哔哩音悦台</title>

<body>
   信号来源
    <a href="https://live.bilibili.com/3?share_source=copy_link">哔哩哔哩音悦台</a>
    
</body>
</html>